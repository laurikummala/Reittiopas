import Comments from '../comments/Comments'

function ReittiSivu() {
    return (
        <div className='content'>
            
           
            <Comments currentUserId="1" />
        </div>
    )
}

export default ReittiSivu;
