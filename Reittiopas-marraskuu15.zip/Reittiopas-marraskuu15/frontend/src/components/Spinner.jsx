function Spinner() {
  return (
    <div className="loadinSpinnerContainer">
      <div className="loadinSpinner"></div>
    </div>
  )
}
export default Spinner